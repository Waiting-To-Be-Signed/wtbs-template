WTBS Collaborative Logo Template
================================

## License

This work is licensed under a Creative Commons
Attribution-NonCommercial-NoDerivatives 4.0 International License
http://creativecommons.org/licenses/by-nc-nd/4.0/

## Imported modules

- P5 - GNU Lesser General Public License 2.1
  https://p5js.org/

- @thi.ng/random-fxhash - Apache Software License 2.0
  https://github.com/thi-ng/umbrella/tree/develop/packages/random-fxhash

- lodash.debounce - MIT
  https://github.com/lodash/lodash
